package br.com.caelum.livraria.dominio;

public enum TipoDeDesconto {
	
	CUPOM_DE_DESCONTO, FIDELIDADE, NENHUM;
}